using FluentAssertions;
using MottoMap.Mappers;
using MottoMap.DTOs.Filial;
using MottoMap.DTOs.Funcionario;
using MottoMap.DTOs.Motos;
using MottoMap.Models;

namespace Testes
{
    /// <summary>
    /// Testes unit�rios para os Mappers
    /// </summary>
    public class MappersTests
    {
        #region Testes de FilialMapper

        [Fact]
        public void FilialMapper_ToEntity_DeveConverterCorretamente()
        {
   // Arrange
   var createDto = new CreateFilialDto
            {
     Nome = "Filial Teste",
      Endereco = "Rua Teste, 123",
                Cidade = "S�o Paulo",
      Estado = "sp", // min�sculo para testar convers�o
       CEP = "01234-567"
            };

            // Act
    var entity = FilialMapper.ToEntity(createDto);

    // Assert
      entity.Should().NotBeNull();
   entity.Nome.Should().Be(createDto.Nome);
         entity.Endereco.Should().Be(createDto.Endereco);
      entity.Cidade.Should().Be(createDto.Cidade);
            entity.Estado.Should().Be("SP"); // Deve estar em mai�sculo
       entity.CEP.Should().Be(createDto.CEP);
        }

  [Fact]
      public void FilialMapper_ToResponseDto_DeveConverterCorretamente()
 {
            // Arrange
            var entity = new FilialEntity
            {
        IdFilial = 1,
    Nome = "Filial Teste",
              Endereco = "Rua Teste, 123",
  Cidade = "S�o Paulo",
                Estado = "SP",
      CEP = "01234-567"
    };

        // Act
    var dto = FilialMapper.ToResponseDto(entity);

    // Assert
  dto.Should().NotBeNull();
         dto.IdFilial.Should().Be(entity.IdFilial);
 dto.Nome.Should().Be(entity.Nome);
     dto.Endereco.Should().Be(entity.Endereco);
            dto.Cidade.Should().Be(entity.Cidade);
     dto.Estado.Should().Be(entity.Estado);
     dto.CEP.Should().Be(entity.CEP);
    }

        #endregion

        #region Testes de FuncionarioMapper

     [Fact]
        public void FuncionarioMapper_ToEntity_DeveConverterCorretamente()
     {
  // Arrange
   var createDto = new CreateFuncionarioDto
     {
    Nome = "Jo�o Silva",
      Email = "joao@mottomap.com",
         IdFilial = 1,
        Funcao = "Gerente"
            };

          // Act
     var entity = FuncionarioMapper.ToEntity(createDto);

       // Assert
      entity.Should().NotBeNull();
 entity.Nome.Should().Be(createDto.Nome);
            entity.Email.Should().Be(createDto.Email);
      entity.IdFilial.Should().Be(createDto.IdFilial);
 entity.Funcao.Should().Be(createDto.Funcao);
        }

        [Fact]
        public void FuncionarioMapper_ToResponseDto_DeveConverterCorretamente()
        {
   // Arrange
          var entity = new FuncionarioEntity
            {
     IdFuncionario = 1,
                Nome = "Jo�o Silva",
          Email = "joao@mottomap.com",
        IdFilial = 1,
           Funcao = "Gerente"
            };

      // Act
      var dto = FuncionarioMapper.ToResponseDto(entity);

            // Assert
            dto.Should().NotBeNull();
    dto.IdFuncionario.Should().Be(entity.IdFuncionario);
     dto.Nome.Should().Be(entity.Nome);
       dto.Email.Should().Be(entity.Email);
    dto.IdFilial.Should().Be(entity.IdFilial);
         dto.Funcao.Should().Be(entity.Funcao);
        }

        #endregion

        #region Testes de MotoMapper

        [Fact]
     public void MotoMapper_ToEntity_DeveConverterCorretamente()
        {
            // Arrange
   var createDto = new CreateMotoDto
       {
      Marca = "Honda",
           Modelo = "CG 160 Titan",
     Ano = 2023,
        Placa = "abc-1234", // min�sculo para testar convers�o
        IdFilial = 1,
    Cor = "Vermelha",
    Quilometragem = 5000
    };

        // Act
            var entity = MotoMapper.ToEntity(createDto);

            // Assert
            entity.Should().NotBeNull();
      entity.Marca.Should().Be(createDto.Marca);
   entity.Modelo.Should().Be(createDto.Modelo);
         entity.Ano.Should().Be(createDto.Ano);
     entity.Placa.Should().Be("ABC-1234"); // Deve estar em mai�sculo
       entity.IdFilial.Should().Be(createDto.IdFilial);
         entity.Cor.Should().Be(createDto.Cor);
         entity.Quilometragem.Should().Be(createDto.Quilometragem);
        }

        [Fact]
     public void MotoMapper_FormatPlaca_PlacaAntiga_DeveFormatarCorretamente()
        {
            // Arrange
            string placaSemFormatacao = "ABC1234";

            // Act
            var placaFormatada = MotoMapper.FormatPlaca(placaSemFormatacao);

// Assert
            placaFormatada.Should().Be("ABC-1234");
        }

     [Fact]
   public void MotoMapper_FormatPlaca_PlacaMercosul_DeveManter()
        {
         // Arrange
    string placaMercosul = "ABC1D23";

  // Act
      var placaFormatada = MotoMapper.FormatPlaca(placaMercosul);

            // Assert
            placaFormatada.Should().Be("ABC1D23");
  }

    [Fact]
        public void MotoMapper_FormatPlaca_PlacaMinuscula_DeveConverterParaMaiuscula()
        {
        // Arrange
     string placaMinuscula = "abc-1234";

            // Act
       var placaFormatada = MotoMapper.FormatPlaca(placaMinuscula);

// Assert
        placaFormatada.Should().Be("ABC-1234");
        }

        #endregion

    #region Testes de PaginationMapper

    [Fact]
        public void PaginationMapper_CreateError_DeveCriarErrorResponse()
        {
            // Arrange
         string code = "TEST_ERROR";
   string message = "Mensagem de erro de teste";

// Act
       var error = PaginationMapper.CreateError(code, message);

       // Assert
     error.Should().NotBeNull();
            error.Code.Should().Be(code);
   error.Message.Should().Be(message);
     error.Timestamp.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
        }

        [Fact]
     public void PaginationMapper_CreateSuccess_DeveCriarSuccessResponse()
        {
            // Arrange
            string message = "Opera��o realizada com sucesso";
    var data = new { Id = 1, Nome = "Teste" };

            // Act
        var success = PaginationMapper.CreateSuccess(message, data);

       // Assert
            success.Should().NotBeNull();
    success.Message.Should().Be(message);
   success.Data.Should().Be(data);
            success.Timestamp.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
        }

        #endregion
    }
}
