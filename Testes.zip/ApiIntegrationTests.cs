using Microsoft.AspNetCore.Mvc.Testing;
using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using MottoMap.DTOs.Filial;
using MottoMap.DTOs.Funcionario;
using MottoMap.DTOs.Motos;
using MottoMap.DTOs.Common;

namespace Testes
{
    /// <summary>
    /// Testes de integra��o b�sicos da API MottoMap
    /// </summary>
public class ApiIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly HttpClient _client;

        public ApiIntegrationTests(WebApplicationFactory<Program> factory)
        {
       _client = factory.CreateClient();
        }

        #region Testes de Filiais

        [Fact]
    public async Task GET_Filiais_RetornaListaPaginada()
        {
     // Act
            var response = await _client.GetAsync("/api/v1/filiais?pageNumber=1&pageSize=10");

 // Assert
 response.StatusCode.Should().Be(HttpStatusCode.OK);
    var result = await response.Content.ReadFromJsonAsync<PagedResponseDto<FilialResponseDto>>();
            result.Should().NotBeNull();
 result!.Pagination.Should().NotBeNull();
        }

        [Fact]
        public async Task POST_Filial_CriaComSucesso()
        {
            // Arrange
 var novaFilial = new CreateFilialDto
            {
       Nome = $"Filial Teste {Guid.NewGuid()}",
      Endereco = "Rua Teste, 123",
    Cidade = "S�o Paulo",
       Estado = "SP",
    CEP = "01234-567"
   };

            // Act
     var response = await _client.PostAsJsonAsync("/api/v1/filiais", novaFilial);

        // Assert
            response.StatusCode.Should().Be(HttpStatusCode.Created);
      var result = await response.Content.ReadFromJsonAsync<FilialResponseDto>();
  result.Should().NotBeNull();
       result!.Nome.Should().Be(novaFilial.Nome);
        result.IdFilial.Should().BeGreaterThan(0);
        }

        [Fact]
        public async Task POST_Filial_ComEstadoInvalido_RetornaBadRequest()
        {
            // Arrange
       var filialInvalida = new CreateFilialDto
  {
    Nome = "Filial Teste",
           Endereco = "Rua Teste",
 Cidade = "S�o Paulo",
        Estado = "SAO", // Inv�lido - deve ter 2 caracteres
        CEP = "01234-567"
         };

            // Act
            var response = await _client.PostAsJsonAsync("/api/v1/filiais", filialInvalida);

    // Assert
            response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

      #endregion

        #region Testes de Funcion�rios

        [Fact]
        public async Task GET_Funcionarios_RetornaListaPaginada()
        {
      // Act
            var response = await _client.GetAsync("/api/v1/funcionarios?pageNumber=1&pageSize=10");

      // Assert
 response.StatusCode.Should().Be(HttpStatusCode.OK);
       var result = await response.Content.ReadFromJsonAsync<PagedResponseDto<FuncionarioResponseDto>>();
     result.Should().NotBeNull();
        }

        [Fact]
public async Task POST_Funcionario_ComFilialValida_CriaComSucesso()
        {
       // Arrange - Primeiro criar uma filial
  var filial = new CreateFilialDto
      {
                Nome = $"Filial para Funcion�rio {Guid.NewGuid()}",
          Endereco = "Rua Teste, 456",
     Cidade = "Rio de Janeiro",
                Estado = "RJ",
        CEP = "20000-000"
            };
var filialResponse = await _client.PostAsJsonAsync("/api/v1/filiais", filial);
   var filialCriada = await filialResponse.Content.ReadFromJsonAsync<FilialResponseDto>();

       var novoFuncionario = new CreateFuncionarioDto
       {
    Nome = "Jo�o Silva Teste",
                Email = $"joao.teste.{Guid.NewGuid()}@mottomap.com",
  IdFilial = filialCriada!.IdFilial,
       Funcao = "Analista de Testes"
     };

   // Act
   var response = await _client.PostAsJsonAsync("/api/v1/funcionarios", novoFuncionario);

     // Assert
response.StatusCode.Should().Be(HttpStatusCode.Created);
var result = await response.Content.ReadFromJsonAsync<FuncionarioResponseDto>();
   result.Should().NotBeNull();
   result!.Nome.Should().Be(novoFuncionario.Nome);
         result.Email.Should().Be(novoFuncionario.Email);
        }

   [Fact]
  public async Task POST_Funcionario_ComEmailInvalido_RetornaBadRequest()
        {
          // Arrange
            var funcionarioInvalido = new CreateFuncionarioDto
      {
        Nome = "Teste",
      Email = "email-invalido", // Email sem formato v�lido
            IdFilial = 1,
        Funcao = "Teste"
            };

            // Act
var response = await _client.PostAsJsonAsync("/api/v1/funcionarios", funcionarioInvalido);

    // Assert
   response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
   }

        [Fact]
        public async Task POST_Funcionario_ComFilialInexistente_RetornaBadRequest()
        {
         // Arrange
  var funcionario = new CreateFuncionarioDto
  {
      Nome = "Teste",
       Email = $"teste.{Guid.NewGuid()}@mottomap.com",
       IdFilial = 99999, // Filial que n�o existe
                Funcao = "Teste"
      };

      // Act
            var response = await _client.PostAsJsonAsync("/api/v1/funcionarios", funcionario);

            // Assert
          response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
      }

        #endregion

   #region Testes de Motos

 [Fact]
        public async Task GET_Motos_RetornaListaPaginada()
 {
            // Act
  var response = await _client.GetAsync("/api/v1/motos?pageNumber=1&pageSize=10");

   // Assert
  response.StatusCode.Should().Be(HttpStatusCode.OK);
  var result = await response.Content.ReadFromJsonAsync<PagedResponseDto<MotoResponseDto>>();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task POST_Moto_ComDadosValidos_CriaComSucesso()
 {
// Arrange - Criar filial primeiro
      var filial = new CreateFilialDto
   {
 Nome = $"Filial para Moto {Guid.NewGuid()}",
    Endereco = "Rua Teste, 789",
          Cidade = "Belo Horizonte",
           Estado = "MG",
 CEP = "30000-000"
     };
    var filialResponse = await _client.PostAsJsonAsync("/api/v1/filiais", filial);
      var filialCriada = await filialResponse.Content.ReadFromJsonAsync<FilialResponseDto>();

   var novaMoto = new CreateMotoDto
     {
       Marca = "Honda",
        Modelo = "CG 160 Titan Teste",
Ano = 2023,
      Placa = $"TST-{Random.Shared.Next(1000, 9999)}", // Placa �nica no formato correto
             IdFilial = filialCriada!.IdFilial,
  Cor = "Vermelha",
    Quilometragem = 1000
          };

            // Act
     var response = await _client.PostAsJsonAsync("/api/v1/motos", novaMoto);

  // Assert
  response.StatusCode.Should().Be(HttpStatusCode.Created);
  var result = await response.Content.ReadFromJsonAsync<MotoResponseDto>();
         result.Should().NotBeNull();
        result!.Marca.Should().Be(novaMoto.Marca);
        result.Modelo.Should().Be(novaMoto.Modelo);
        }

        [Fact]
   public async Task POST_Moto_ComAnoInvalido_RetornaBadRequest()
   {
            // Arrange
    var motoInvalida = new CreateMotoDto
       {
            Marca = "Honda",
     Modelo = "CG 160",
       Ano = 1850, // Ano inv�lido
    Placa = "TST-1234",
      IdFilial = 1,
   Cor = "Azul"
          };

            // Act
var response = await _client.PostAsJsonAsync("/api/v1/motos", motoInvalida);

      // Assert
            response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
   }

        [Fact]
        public async Task GET_Motos_PorMarca_RetornaFiltrado()
{
     // Act
      var response = await _client.GetAsync("/api/v1/motos/marca/Honda");

            // Assert
  response.StatusCode.Should().Be(HttpStatusCode.OK);
            var result = await response.Content.ReadFromJsonAsync<PagedResponseDto<MotoResponseDto>>();
    result.Should().NotBeNull();
        }

   #endregion

        #region Testes de Pagina��o

        [Fact]
        public async Task GET_ComPaginacao_RetornaMetadadosCorretos()
        {
   // Arrange
     int pageNumber = 1;
            int pageSize = 5;

     // Act
       var response = await _client.GetAsync($"/api/v1/filiais?pageNumber={pageNumber}&pageSize={pageSize}");

   // Assert
            response.StatusCode.Should().Be(HttpStatusCode.OK);
          var result = await response.Content.ReadFromJsonAsync<PagedResponseDto<FilialResponseDto>>();
    result.Should().NotBeNull();
   result!.Pagination.PageNumber.Should().Be(pageNumber);
            result.Pagination.PageSize.Should().Be(pageSize);
       result.Data.Count().Should().BeLessThanOrEqualTo(pageSize);
     }

        [Fact]
        public async Task GET_ComBusca_RetornaResultadosFiltrados()
     {
            // Act
      var response = await _client.GetAsync("/api/v1/filiais?searchTerm=teste&pageSize=10");

            // Assert
       response.StatusCode.Should().Be(HttpStatusCode.OK);
        var result = await response.Content.ReadFromJsonAsync<PagedResponseDto<FilialResponseDto>>();
     result.Should().NotBeNull();
      }

   #endregion

      #region Testes de Status Codes

        [Fact]
        public async Task GET_RecursoInexistente_RetornaNotFound()
      {
       // Act
            var response = await _client.GetAsync("/api/v1/funcionarios/99999");

            // Assert
      response.StatusCode.Should().Be(HttpStatusCode.NotFound);
        }

        [Fact]
        public async Task DELETE_RecursoInexistente_RetornaNotFound()
    {
            // Act
          var response = await _client.DeleteAsync("/api/v1/motos/99999");

   // Assert
      response.StatusCode.Should().Be(HttpStatusCode.NotFound);
        }

        #endregion

     #region Testes de HATEOAS

        [Fact]
public async Task GET_Filial_RetornaComLinksHATEOAS()
        {
  // Arrange - Criar uma filial primeiro
            var novaFilial = new CreateFilialDto
       {
     Nome = $"Filial HATEOAS {Guid.NewGuid()}",
Endereco = "Rua HATEOAS, 123",
         Cidade = "Curitiba",
     Estado = "PR",
                CEP = "80000-000"
       };
            var createResponse = await _client.PostAsJsonAsync("/api/v1/filiais", novaFilial);
            var filialCriada = await createResponse.Content.ReadFromJsonAsync<FilialResponseDto>();

         // Act
   var response = await _client.GetAsync($"/api/v1/filiais/{filialCriada!.IdFilial}");

 // Assert
 response.StatusCode.Should().Be(HttpStatusCode.OK);
            var result = await response.Content.ReadFromJsonAsync<FilialResponseDto>();
    result.Should().NotBeNull();
            result!.Links.Should().NotBeEmpty();
    result.Links.Should().ContainKey("self");
       result.Links.Should().ContainKey("update");
 result.Links.Should().ContainKey("delete");
        }

        #endregion
    }
}
