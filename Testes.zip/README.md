# Projeto de Testes (Testes)

Este repositório contém o projeto em testes referente a MottoMap API, tivemos que fazer separadamente pois o Visual Studio não estava acatando o projeto novo dando diversos erros de compilação. Foram feitos todos os esforços para integrá-lo mas não foi possível. Agradeço a compreensão.

## Visão geral

- Projeto: `Testes` (projeto de testes .NET)
- Principais arquivos de teste:
  - `ApiIntegrationTests.cs` — testes de integração para APIs
  - `MappersTests.cs` — testes de unidade para mapeamentos
- Arquivo de projeto: `Testes.csproj`

O projeto alvo foi compilado para .NET 8.0 (ver pastas `bin/` e `obj/`).

## O que os testes estão fazendo

### `ApiIntegrationTests.cs` - Testes de Integração da API MottoMap

Este arquivo contém testes de integração que validam os endpoints da API MottoMap usando `WebApplicationFactory`. Os testes cobrem:

#### **Testes de Filiais**
- ✅ **GET_Filiais_RetornaListaPaginada**: Valida que o endpoint GET `/api/v1/filiais` retorna uma lista paginada com status 200 OK.
- ✅ **POST_Filial_CriaComSucesso**: Testa a criação de uma nova filial com dados válidos e valida que retorna status 201 Created com ID gerado.
- ✅ **POST_Filial_ComEstadoInvalido_RetornaBadRequest**: Valida que filiais com estado inválido (3 caracteres ao invés de 2) retornam 400 Bad Request.

#### **Testes de Funcionários**
- ✅ **GET_Funcionarios_RetornaListaPaginada**: Valida que o endpoint GET `/api/v1/funcionarios` retorna uma lista paginada.
- ✅ **POST_Funcionario_ComFilialValida_CriaComSucesso**: Testa criação de funcionário vinculado a uma filial válida e valida os dados retornados.
- ✅ **POST_Funcionario_ComEmailInvalido_RetornaBadRequest**: Valida que emails sem formato válido retornam 400 Bad Request.
- ✅ **POST_Funcionario_ComFilialInexistente_RetornaBadRequest**: Valida que criar funcionário com ID de filial inexistente retorna 400 Bad Request.

#### **Testes de Motos**
- ✅ **GET_Motos_RetornaListaPaginada**: Valida que o endpoint GET `/api/v1/motos` retorna uma lista paginada.
- ✅ **POST_Moto_ComDadosValidos_CriaComSucesso**: Testa criação de moto com dados válidos (marca, modelo, ano, placa, cor, quilometragem).
- ✅ **POST_Moto_ComAnoInvalido_RetornaBadRequest**: Valida que motos com ano inválido (ex: 1850) retornam 400 Bad Request.
- ✅ **GET_Motos_PorMarca_RetornaFiltrado**: Testa endpoint de filtro por marca `/api/v1/motos/marca/{marca}`.

#### **Testes de Paginação**
- ✅ **GET_ComPaginacao_RetornaMetadadosCorretos**: Valida que os metadados de paginação (pageNumber, pageSize) são retornados corretamente.
- ✅ **GET_ComBusca_RetornaResultadosFiltrados**: Testa funcionalidade de busca/pesquisa com parâmetro `searchTerm`.

#### **Testes de Status Codes**
- ✅ **GET_RecursoInexistente_RetornaNotFound**: Valida que GET de recursos inexistentes retorna 404 Not Found.
- ✅ **DELETE_RecursoInexistente_RetornaNotFound**: Valida que DELETE de recursos inexistentes retorna 404 Not Found.

#### **Testes de HATEOAS**
- ✅ **GET_Filial_RetornaComLinksHATEOAS**: Valida que as respostas incluem links HATEOAS (self, update, delete) seguindo o padrão REST.

### `MappersTests.cs` - Testes Unitários de Mappers

Este arquivo contém testes unitários para os mapeadores (Mappers) que convertem entre DTOs e Entidades. Os testes cobrem:

#### **FilialMapper**
- ✅ **FilialMapper_ToEntity_DeveConverterCorretamente**: Valida conversão de `CreateFilialDto` para `FilialEntity`, incluindo conversão de estado para maiúsculo.
- ✅ **FilialMapper_ToResponseDto_DeveConverterCorretamente**: Valida conversão de `FilialEntity` para `FilialResponseDto` com todos os campos corretos.

#### **FuncionarioMapper**
- ✅ **FuncionarioMapper_ToEntity_DeveConverterCorretamente**: Valida conversão de `CreateFuncionarioDto` para `FuncionarioEntity`.
- ✅ **FuncionarioMapper_ToResponseDto_DeveConverterCorretamente**: Valida conversão de `FuncionarioEntity` para `FuncionarioResponseDto`.

#### **MotoMapper**
- ✅ **MotoMapper_ToEntity_DeveConverterCorretamente**: Valida conversão de `CreateMotoDto` para `MotoEntity`, incluindo formatação e conversão de placa para maiúsculo.
- ✅ **MotoMapper_FormatPlaca_PlacaAntiga_DeveFormatarCorretamente**: Testa formatação de placas antigas (ABC1234 → ABC-1234).
- ✅ **MotoMapper_FormatPlaca_PlacaMercosul_DeveManter**: Valida que placas Mercosul (ABC1D23) são mantidas sem formatação adicional.
- ✅ **MotoMapper_FormatPlaca_PlacaMinuscula_DeveConverterParaMaiuscula**: Testa conversão de placas minúsculas para maiúsculas.

#### **PaginationMapper**
- ✅ **PaginationMapper_CreateError_DeveCriarErrorResponse**: Valida criação de respostas de erro com código, mensagem e timestamp.
- ✅ **PaginationMapper_CreateSuccess_DeveCriarSuccessResponse**: Valida criação de respostas de sucesso com mensagem, dados e timestamp.

### Tecnologias e Bibliotecas Utilizadas

- **xUnit**: Framework de testes.
- **FluentAssertions**: Biblioteca para asserções fluentes e legíveis.
- **WebApplicationFactory**: Para testes de integração da API sem servidor HTTP real.
- **.NET 8.0**: Plataforma de execução.

## Pré-requisitos

- .NET SDK 8.0 instalado (ou a versão indicada no arquivo `.runtimeconfig.json` do projeto).
- PowerShell (no Windows) — instruções abaixo usam `powershell.exe`.

## Estrutura principal do repositório

- `Testes/` — código fonte do projeto de testes.
- `Testes.csproj` — definição do projeto de testes.
- `ApiIntegrationTests.cs`, `MappersTests.cs` — exemplos de testes.
- `bin/`, `obj/` — diretórios de build gerados.



